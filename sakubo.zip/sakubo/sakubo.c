#include <stdio.h>
#include <stdlib.h> 
#include <string.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 7890

void *ec_malloc(unsigned int);
void fatal(char *);

int main(){
	FILE *fp;
	char data[128];
	char sendtext[1024];

	pid_t pid;

	int sockfd, new_sockfd, status;
	int yes = 1;
	int linecount = 0;
	struct sockaddr_in host_addr, client_addr;
	socklen_t sin_size;

	char description[] = "\nHello! This is a service which introduces a book to you.\nInput the chapter number!\n\nMenu:\n1) Chapter 1\n2) Chapter 2\n3) Chapter 3\nq) Exit\n\n* Otherwise display all the chapters.\n\n";
	char copyright[] = "\n-*- 2ND EDITION HACKING THE ART OF EXPLOITATION, JON ERICKSON -*-\n";
	char *buffer, *datafile;

	buffer = (char *) ec_malloc(32); 
	datafile = (char *) ec_malloc(16);
	strcpy(datafile, "./var/note");

	if((sockfd = socket(PF_INET, SOCK_STREAM, 0)) == -1){
		fatal("in socket.");
	}
	if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1){
		fatal("socket opt SO_REUSEADDR.");
	}

	host_addr.sin_family = AF_INET;
	host_addr.sin_port = htons(PORT);
	host_addr.sin_addr.s_addr = 0;
	memset(&(host_addr.sin_zero), '\0', 8);

	if(bind(sockfd, (struct sockaddr *)&host_addr, sizeof(struct sockaddr)) == -1){
		fatal("binding to socket.");
	}

	if(listen(sockfd, 5) == -1){
		fatal("listening on socket.");
	}

	sin_size = sizeof(struct sockaddr_in);
	while(1){
		new_sockfd = accept(sockfd, (struct sockaddr *)&client_addr, &sin_size);
		if(new_sockfd == -1){
			fatal("accepting connection.");
		}

		if((pid = fork()) == -1){
			fatal("failed to fork.");
		}

		if(pid == 0){
			printf("\nserver: got connection from %s port %d\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
			send(new_sockfd, description, sizeof(description), 0);
			recv(new_sockfd, buffer, 64, 0);
			printf("Input data : %s", buffer);

			fp = fopen(datafile, "r");
			if(fp == NULL){
				send(new_sockfd, "Error!\n", 7, 0);
				printf("%s : failed to open file.\n", inet_ntoa(client_addr.sin_addr));
				exit(1);
			}	

			if(strcmp(buffer, "1\n") == 0){
				strcpy(sendtext, "--------------------------------------------------------------------\n");
				while(fgets(data, sizeof(data), fp) != NULL){
					strcat(sendtext, data);
					if(strcmp(data, "\n") == 0){
						break;
					}
				}
				strcat(sendtext, copyright);
				strcat(sendtext, "--------------------------------------------------------------------\n");
			}
			else if(strcmp(buffer, "2\n") == 0){
				strcpy(sendtext, "--------------------------------------------------------------------\n");
				while(fgets(data, sizeof(data), fp) != NULL){
					if(linecount == 1){
						strcat(sendtext, data);
					}
					if(strcmp(data, "\n") == 0){
						linecount++;
					}
				}
				strcat(sendtext, copyright);
				strcat(sendtext, "--------------------------------------------------------------------\n");
			}
			else if(strcmp(buffer, "3\n") == 0){
				strcpy(sendtext, "--------------------------------------------------------------------\n");
				while(fgets(data, sizeof(data), fp) != NULL){
					if(linecount == 2){
						strcat(sendtext, data);
					}
					if(strcmp(data, "\n") == 0){
						linecount++;
					}
				}
				strcat(sendtext, copyright);
				strcat(sendtext, "--------------------------------------------------------------------\n");
			}
			else if(strcmp(buffer, "q\n") == 0){
				strcpy(sendtext, "bye!\n");
			}
			else{
				strcpy(sendtext, "--------------------------------------------------------------------\n");
				while(fgets(data, sizeof(data), fp) != NULL){
					strcat(sendtext, data);
				}
				strcat(sendtext, copyright);
				strcat(sendtext, "--------------------------------------------------------------------\n");
			}

			send(new_sockfd, sendtext, strlen(sendtext), 0);

			close(new_sockfd);
			close(sockfd);

			fclose(fp);

			printf("%s : END\n", inet_ntoa(client_addr.sin_addr));
			printf("-----------------------------------------------\n");

			exit(0);
		}
		else{
			waitpid(pid, &status, 0);
		}
		close(new_sockfd);
	}

	close(sockfd);
	free(buffer); 
	free(datafile);

	return 0;
}

void *ec_malloc(unsigned int size){
	void *ptr; 
	ptr = malloc(size); 
	if(ptr == NULL){
		printf("Error, could not allocate heap memory.\n"); 
	}
	return ptr;
}

void fatal(char *message){
	char error_message[128];

	strcpy(error_message, "Error, ");
	strncat(error_message, message, 128); 
	printf("%s\n", error_message); 
	exit(1);
}
