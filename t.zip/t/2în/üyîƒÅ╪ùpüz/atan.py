# -*- coding: sjis -*-

import math
import random


print "0:0  45:0.78  90:1.57  135:2.35  180:3.14  -45:-0.78  -90:-1.57  -135:-2.35  -180:-3.14\n"

d = 2 * math.pi * (random.uniform(0, 360) / 360)

x = 500
y = 500
s = 10

xd = random.randint(0, 1000)
yd = random.randint(0, 1000)

d = math.atan2((yd - y), (xd - x))

print x, y, xd, yd, d

x = int(x + (2 * s * math.cos(d)))
y = int(y + (2 * s * math.sin(d)))

print x, y

for i in range(20):
	x = int(x + (2 * s * math.cos(d)))
	y = int(y + (2 * s * math.sin(d)))
	d = math.atan2((yd - y), (xd - x))
	print x, y