# -*- coding: sjis -*-

def func(list):

	templist = list
	templist[0] = list[1]
	return templist

if __name__ == "__main__":

	temp2 = []
	temp3 = []

	temp2.append(1)
	temp2.append(2)
	temp2.append(3)

	print temp2

	print "-------\n"

	temp3 = func(temp2)

	print "temp2 = ", temp2
	print "temp3 = ", temp3
