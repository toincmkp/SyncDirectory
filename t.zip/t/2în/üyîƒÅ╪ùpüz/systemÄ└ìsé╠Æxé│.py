import os

os.system("cls")

i = 15000
j = 0

while j != i:
	print j, "/", i
#	os.system("cls")
	j += 1

print "end"