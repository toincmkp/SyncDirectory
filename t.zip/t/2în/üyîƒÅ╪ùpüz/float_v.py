if (1.2 - 0.2 == 1.0):
	print "In"

else:
	print "Not In"

print "end"
