import sys

txt = "GNrDNdeyMmuNaHnhZDpJtRSLpvypFhPXzxLBwVBISmyIhtMTQXeLOfAFrVjAESSflIzxxAnyangFlzLAQVESahvDXtmnKNBRpIkfpSMRLNFnHViPJhqvuhrrpfymLjhBJlZFdNlYswhNlImRlKzWwzjlpigqOHVSnNxxgpSccwyoHPACOBPTGZfmXDBAHdWDHrcVpXIZwFMTQuWdSgGHgtUtiBXcGEDGhgMaGyanBffyKcGFiQjRnqSrvOrlJYFbvHCWLsqPRiUcCwMuzioVrOmEjQwffudNDwnkDeijzqzRHzNVwZaWsZvMrhlsLjRGUFbe"

print txt
print "-------------------------"

temp = 0


for i in range(2, 19):
	print "------------------------------"
	sys.stdout.write("i = ")
	print i
	print "------------------------------"


	for c in txt:
		if (temp % i == 0):
			sys.stdout.write("\n")

		sys.stdout.write(c+"  ")
		temp += 1

		if (temp == 324):
			break

	temp = 0
	print "\n"

