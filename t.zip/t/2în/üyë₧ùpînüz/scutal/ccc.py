import sys

f = open("t3.txt", "r")

for line in f:
#	print line
	sys.stdout.write(line)

f.close