f = open("t.txt", "r")


search = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ\n"
array = []
# for c in search:
# 	array[c] = 0

array[61] = 0


# for line in f:
#	for c in line:
#		array[c] += 1



f.close