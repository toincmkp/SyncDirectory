f = open("t2.txt", "r")


search = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ\n"
array = {}
for c in search:
	array[c] = 0


for line in f:
	for c in line:
		array[c] += 1

for k, v in sorted(array.items()):
	print k, ":", v

f.close