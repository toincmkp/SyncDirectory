s = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"#$%&'()*+,-./:;<=>?@[\]^_`{|}~ "
k = "QRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!\"#$%&'()*+,-./:;<=>?@[\]^_`{|}~ ABCDEFGHIJKLMNOP"

encript = "..PXu74u8Ph4489PR!77{{"
decript = ""

print ""
print "before :", s
print "after  :", k

for c in encript:
	decript += s[k.find(c)]

# decript = ''.join(s[k.find(c)] for c in encript)

print ""
print "encript :", encript
print "decript :", decript

