import random, time

k = 0

for i in range(50):

	x = random.randint(1, 1000)

	x = x/2000.0

	time.sleep(x)

	print k, x

	k += 1