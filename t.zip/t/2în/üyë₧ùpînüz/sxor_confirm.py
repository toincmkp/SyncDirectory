# -*- coding:sjis -*-

import base64

def sxor(s1,s2):

    if len(s1) < len(s2):

        q = len(s2) / len(s1)
        r = len(s2) % len(s1)
        print "q = %d, r = %d" % (q, r)

        if r == 0:
            s1 = s1 * q

        else:
            s0 = s1
            s1 = s1 * q

            for i in range(0, r):
                s1 = s1 + (s0[i])

        print s1
        print s2

    if len(s1) > len(s2):

        q = len(s1) / len(s2)
        r = len(s1) % len(s2)
        print "q = %d, r = %d" % (q, r)

        if r == 0:
            s2 = s2 * q

        else:
            s0 = s2
            s2 = s2 * q

            for i in range(0, r):
                s2 = s2 + (s0[i])

        print s1
        print s2

    return ''.join(chr(ord(a) ^ ord(b)) for a,b in zip(s1,s2))


x = "F05RR"
y = "ABCDDfafa"

z = sxor(x, y)

print "%s" % base64.b64encode(z)

print sxor(z, y)
# print "%s" % ((str(int(x) ^ int(y)))
