flag_2 = 0
flag_3 = 0
flag_5 = 0

f_2 = 2
f_3 = 3
f_5 = 5

k_2 = 2
k_3 = 3
k_5 = 5

for i in range(1, 50):

	if i == f_2:
		flag_2 = 1
		f_2 += k_2

	if i == f_3:
		flag_3 = 1
		f_3 += k_3

	if i == f_5:
		flag_5 = 1
		f_5 += k_5

	if (flag_2 or flag_3 or flag_5) == 0:
			print i

	flag_2 = 0
	flag_3 = 0
	flag_5 = 0

