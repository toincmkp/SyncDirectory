f = open("pi.txt", 'r')
list = []


for line in f:
	line = line.replace(" ", "")
	line = line.replace("\n", "")
	line = line.replace("\n", "")

	list.append(line)


str = "".join(list)
print str

f.close()
