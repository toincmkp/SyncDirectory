s = "12345"
list = []

for i in s:
	print i
	list.append(i)

print list
s = "".join(list)
print int(s) * 2