print "213 = " + bin(213)
print "161 = " + bin(161)

print 213 & 161, "=", bin(213 & 161)

print "\nhex(dd) | int(34)", "=", 0xdd | 34

print 0xff ^ 1