import random

num = random.randint(1, 15)

print "num = %d" % num
g = num

print hex(g)
print bin(g)