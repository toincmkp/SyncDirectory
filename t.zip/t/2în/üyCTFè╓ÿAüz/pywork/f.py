def hello():
	print "hello"

def hello2(name):
	print "hello %s!" % name

def hello3(name, num):
	print "hello %s!" % name * num

def hello4(name, num = 3):
	print "hello %s! " % name * num

def hello5(name, num = 2):
	return "hello %s! " % name * num


hello()
hello2("tagu")
hello3("tagu", 3)
hello4("steve")
hello4(num = 2, name = "tom")

s = hello5("Bob")
print s
