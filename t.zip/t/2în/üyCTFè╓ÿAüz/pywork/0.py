import random, time

for i in range(5):
	num = random.randint(1, 15)

	print "bin =",

	sbin = str(bin(num)).replace("0b", "")

	if len(sbin) == 1:
		print "000" + sbin

	elif len(sbin) == 2:
		print "00" + sbin

	elif len(sbin) == 3:
		print "0" + sbin

	else:
		print sbin

	time.sleep(1)

	print "hex = " + str(hex(num)).replace("0x", "")
	print "----------"
	time.sleep(0.5)