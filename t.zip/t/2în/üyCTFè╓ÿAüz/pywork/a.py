enc = "znk gtyckx zu znoy yzgmk oy tuzbkxengxj"

for x in enc:
	print x