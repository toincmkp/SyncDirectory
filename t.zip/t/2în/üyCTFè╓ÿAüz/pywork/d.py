for i in range(16):
    for j in range(16):
        print "%4s" % bin(i ^ j).replace("0b", ""),

    print ""
