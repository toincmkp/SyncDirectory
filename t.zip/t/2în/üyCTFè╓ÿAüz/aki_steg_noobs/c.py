f = open("tes.txt", 'r')

list = []
fix = 45

for line in f:
	list.append(line.rstrip())

for i in range(64):

	k = i

	while k < 2880:
		print list[k]
		k += fix

	print "<br>"


f.close()