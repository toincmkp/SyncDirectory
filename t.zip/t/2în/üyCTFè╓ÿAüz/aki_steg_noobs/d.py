import sys

f = open("tes.txt", 'r')

list = []
fix = 45

for line in f:
	list.append(line.rstrip())

for i in range(64):

	k = i

	while k < 2880:
		sys.stdout.write(list[k])
		k += fix

	print "<br>"


f.close()