# coding: Shift_JIS

f = open("tes.txt", 'w')

f.write("<html>\n")
f.write("<title></title>\n")
f.write("<body>\n")


for i in range(1, 10):
	str1 = "C:\Users\yosuke\Desktop\koma\_00"
	str2 = str(i)
	str3 = ".gif"
	strall = str1 + str2 + str3

	f.write("<IMG SRC=")
	f.write(strall)
	f.write(">\n")

for i in range(10, 100):
	str1 = "C:\Users\yosuke\Desktop\koma\_0"
	str2 = str(i)
	str3 = ".gif"
	strall = str1 + str2 + str3

	f.write("<IMG SRC=")
	f.write(strall)
	f.write(">\n")

for i in range(100, 2881):
	str1 = "C:\Users\yosuke\Desktop\koma\_"
	str2 = str(i)
	str3 = ".gif"
	strall = str1 + str2 + str3

	f.write("<IMG SRC=")
	f.write(strall)
	f.write(">\n")

f.write("</body>\n")
f.write("</html>\n")


f.close()
