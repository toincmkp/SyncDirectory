import subprocess
import sys
p = subprocess.Popen(["./amida"], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
for i in range(1,100000):
    s = ""
    while True:
        c = p.stdout.read(1)
        sys.stdout.write(c)
        sys.stdout.flush()
        s += c
        if c=="?":
            break
    s = s.split("\n")
    if "-------------------" in s[1]:
        tmp = s[1:-1]
        del s[1:]
        for t in tmp:
            t += " "*(len(tmp[0])-len(t))
        for j in range(len(tmp[0])):
            s += [""]
            for k in range(len(tmp)):
                if tmp[k][j]=="-":
                    s[-1] += "|"
                elif tmp[k][j]=="|":
                    s[-1] += "-"
                else:
                    s[-1] += tmp[k][j]
    T = list(s[1])
    j = 2
    while True:
        if "|" not in s[j]:
            break
        ks = -1
        for k in range(len(s[j])):
            if s[j][k]=="-":
                if ks==-1:
                    ks = k
            else:
                if ks!=-1:
                    T[ks-1],T[k] = T[k],T[ks-1]
                    ks = -1
        j += 1
    S = list(s[j])
    for t,s in zip(T,S):
        if s=="*":
            ans = t
        if t=="*":
            ans = s
    print "Ans:", ans
    p.stdin.write(ans+"\n")
    p.stdin.flush()