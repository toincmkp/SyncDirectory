#!/usr/bin/env python

import socket,random,time,thread,sys,os

def connect(server,port):
	print("in1")
	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)	# create a socket
	s.settimeout(3)						# set the timeout to something low
	try:
		s.connect((server,port))				# connect to the socket
		s.settimeout(None)					# set the timeout back to blocking
		return s					# on success return the connected socket
	except socket.error:					# If the socket times out, or something stupid happens
		print('\n'+(80-27)/2*' '+">>>> Connection Failed <<<<\n")
		exit(0)					# just move on to the next rec
	print("Fuck dude, this is NOT good...\nYou have been blocked, or blacklisted!!!")
	exit(1)								# if 

def brute(idnum,dummy):
	print("in2")
	run = 0
	data = ""
	winning_rows = ""
	while True:
		s = connect("3dttt_87277cd86e7cc53d2671888c417f62aa.2014.shallweplayaga.me",1234)
		plays_tried = []
		run+=1
		print("Thread: "+str(idnum)+" try number: "+str(run))
		while True:
			while True:
				data = s.recv(512)
				try:
					data.find("Choose Wisely")
					break
				except ValueError:
					continue
			try:
				while True:
					random.seed(os.urandom(512))
					play = str(random.randrange(0,3))+","+str(random.randrange(0,3))+","+str(random.randrange(0,3))
					if play not in plays_tried: break
				plays_tried.append(play)
				s.send(play.rstrip('\n')+"\n")
				if len(plays_tried) is 26: break
				continue
			except socket.error:
				try:
					data.find("Must go faster...")
					break
				except ValueError:
					print(data)
					exit(0)

while True:
	brute(3, 3)
	
	print("in3")
	continue
