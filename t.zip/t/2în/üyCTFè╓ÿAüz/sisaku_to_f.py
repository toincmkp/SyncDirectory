#!/usr/bin/env python
# -*- coding: utf-8 -*-

import commands

def ext_name(name):
	file_name = name.split(".")
	file_ext = file_name[len(file_name)-1]

	return file_ext

def f_c():
	if file_num == 950:
		commands.getoutput("mv /root/Desktop/aaa/950/950 /root/Desktop/aaa/950/950.tar.bz2")

	if file_num == 900:
		commands.getoutput("mv /root/Desktop/aaa/900/NUL /root/Desktop/aaa/900/NUL.zip")

	if file_num == 895:
		commands.getoutput("mv /root/Desktop/aaa/895/CON /root/Desktop/aaa/895/CON.zip")

	if file_num == 888:
		commands.getoutput("mv /root/Desktop/aaa/888/---------- /root/Desktop/aaa/888/----------.tar.bz2")

	if file_num == 823:
		commands.getoutput("mv /root/Desktop/aaa/823/EOF /root/Desktop/aaa/823/EOF.zip")

	if file_num == 810:
		commands.getoutput("mv /root/Desktop/aaa/810/OUT /root/Desktop/aaa/810/OUT.tar.bz2")

	if file_num == 800:
		commands.getoutput("mv '/root/Desktop/aaa/C:\\' '/root/Desktop/aaa/800'")

	if file_num == 776:
		commands.getoutput("mv '/root/Desktop/aaa/\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\' '/root/Desktop/aaa/776'")

	if file_num == 767:
		commands.getoutput("mv /root/Desktop/aaa/\!\#\@\#\$\!\$\@ '/root/Desktop/aaa/767'")

	if file_num == 723:
		commands.getoutput("mv /root/Desktop/aaa/723/-x /root/Desktop/aaa/723/fuck.tar.gz")

	if file_num == 672:
		commands.getoutput("mv '/root/Desktop/aaa/672/672; while true; do; done' /root/Desktop/aaa/672/fuck.tar.gz")

	if file_num == 667:
		commands.getoutput("mv '/root/Desktop/aaa/667/-rf' /root/Desktop/aaa/667/fuck.tar.gz")

	if file_num == 665:
		commands.getoutput("mv /root/Desktop/aaa/\~\~\~\~\~ '/root/Desktop/aaa/665'")

	if file_num == 657:
		commands.getoutput("mv '/root/Desktop/aaa/657/-rf .' /root/Desktop/aaa/657/fuck.tar.gz")

	if file_num == 654:
		commands.getoutput("mv '/root/Desktop/aaa/654/-rf *' /root/Desktop/aaa/654/fuck.tar.gz")

#	if file_num == 576:
#		commands.getoutput("mv '/root/Desktop/aaa/????' '/root/Desktop/aaa/576'")

	if file_num == 500:
		commands.getoutput("mv '/root/Desktop/aaa/500/500 half_way_done!' /root/Desktop/aaa/500/fuck.tar.bz2")

	if file_num == 499:
		commands.getoutput("mv '/root/Desktop/aaa/499/tmp' /root/Desktop/aaa/499/fuck.tar.bz2")

	if file_num == 498:
		commands.getoutput("mv '/root/Desktop/aaa/498/ctf' /root/Desktop/aaa/498/fuck.tar.gz")

	if file_num == 497:
		commands.getoutput("mv '/root/Desktop/aaa/497/hitcon' /root/Desktop/aaa/497/fuck.tar.bz2")

	if file_num == 496:
		commands.getoutput("mv '/root/Desktop/aaa/496/solve' /root/Desktop/aaa/496/fuck.tar.bz2")

	if file_num == 495:
		commands.getoutput("mv '/root/Desktop/aaa/495/*' /root/Desktop/aaa/495/fuck.tar.bz2")

#	if file_num == 494:
#		commands.getoutput("mv /root/Desktop/aaa/494/\"\`\?\'\@\#\!\*\$\^\(\!\&\$\$\@\^\$\&\(\*\)\+\_\=\-\>\?\<\>\.\,\. /root/Desktop/aaa/494/fuck.tar.bz2")

#	if file_num == 489:
#		commands.getoutput("mv '/root/Desktop/aaa/498/solve.rb' /root/Desktop/aaa/489/fuck.tar.gz")

	if file_num == 487:
		commands.getoutput("mv '/root/Desktop/aaa/487/solve' /root/Desktop/aaa/487/fuck.tar.bz2")

	if file_num == 486:
		commands.getoutput("mv '/root/Desktop/aaa/486/solve.exe' /root/Desktop/aaa/486/fuck.tar.gz")

	if file_num == 479:
		commands.getoutput("mv '/root/Desktop/aaa/479/a.py' /root/Desktop/aaa/479/fuck.tar.bz2")

	if file_num == 478:
		commands.getoutput("mv '/root/Desktop/aaa/478/a.rb' /root/Desktop/aaa/478/fuck.zip")

	if file_num == 477:
		commands.getoutput("mv '/root/Desktop/aaa/477/a.sh' /root/Desktop/aaa/477/fuck.tar.bz2")

	if file_num == 476:
		commands.getoutput("mv '/root/Desktop/aaa/476/a' /root/Desktop/aaa/476/fuck.tar.bz2")

	if file_num == 475:
		commands.getoutput("mv '/root/Desktop/aaa/475/a.exe' /root/Desktop/aaa/475/fuck.tar.gz")

	if file_num == 465:
		commands.getoutput("mv '/root/Desktop/aaa/465/tarmful.py' /root/Desktop/aaa/465/fuck.tar.bz2")

	if file_num == 464:
		commands.getoutput("mv '/root/Desktop/aaa/464/tarmful.rb' /root/Desktop/aaa/464/fuck.tar.gz")

	if file_num == 463:
		commands.getoutput("mv '/root/Desktop/aaa/463/tarmful.sh' /root/Desktop/aaa/463/fuck.tar.gz")

	if file_num == 462:
		commands.getoutput("mv '/root/Desktop/aaa/462/tarmful' /root/Desktop/aaa/462/fuck.zip")

	if file_num == 461:
		commands.getoutput("mv '/root/Desktop/aaa/461/tarmful.exe' /root/Desktop/aaa/461/fuck.tar.bz2")

	if file_num == 449:
		commands.getoutput("mv '/root/Desktop/aaa/449/log' /root/Desktop/aaa/449/fuck.tar.gz")

	if file_num == 448:
		commands.getoutput("mv '/root/Desktop/aaa/448/log.txt' /root/Desktop/aaa/448/fuck.tar.gz")

	if file_num == 447:
		commands.getoutput("mv '/root/Desktop/aaa/447/out' /root/Desktop/aaa/447/fuck.tar.bz2")

	if file_num == 446:
		commands.getoutput("mv '/root/Desktop/aaa/446/out.txt' /root/Desktop/aaa/446/fuck.tar.bz2")

#	if file_num == 420:
#		commands.getoutput("mv /root/Desktop/aaa/420\; rm -rf \*\; '/root/Desktop/aaa/420'")


flag = 0

file_path = "/root/Desktop"
file_name = "1023.zip"
home_dir = "/root/Desktop/aaa"

kk = file_name.split(".")
file_num = int(kk[0])


ext = ext_name(file_name)

print "ext = " + ext

commands.getoutput("mkdir aaa")

while flag == 0:

	if ext == "zip":
		commands.getoutput("unzip " + file_name + " -d "+ home_dir)
		file_num -= 1
		f_c()
		file_name = commands.getoutput("ls -1 " + home_dir + "/" + str(file_num))
		print file_name
		ext = ext_name(file_name)
		file_name = home_dir + "/" + str(file_num) + "/" + file_name

	elif ext == "gz":
		commands.getoutput("tar xzvf " + file_name + " -C "+ home_dir)
		file_num -= 1
		f_c()
		file_name = commands.getoutput("ls -1 " + home_dir + "/" + str(file_num))
		print file_name
		ext = ext_name(file_name)
		file_name = home_dir + "/" + str(file_num) + "/" + file_name

	elif ext == "bz2":
		commands.getoutput("tar -jxf " + file_name + " -C "+ home_dir)
		file_num -= 1
		f_c()
		file_name = commands.getoutput("ls -1 " + home_dir + "/" + str(file_num))
		print file_name
		ext = ext_name(file_name)
		file_name = home_dir + "/" + str(file_num) + "/" + file_name

	else:
		flag = 1
#		sys2 = commands.getoutput("file " + file_name)
#		print sys2
#		sys2 = sys2.split(" ")
#		print sys2[1]

#		commands.getoutput("rm -r aaa")

print "end"