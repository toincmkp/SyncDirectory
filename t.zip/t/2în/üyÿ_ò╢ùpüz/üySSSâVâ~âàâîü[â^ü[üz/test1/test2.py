p = 1.9999999999999999999999999999
w = 2.0000000000000000000000000001

print round(p)
print round(w)

s = 1
for i in range(1,10):
    s = s * p * w
print s
