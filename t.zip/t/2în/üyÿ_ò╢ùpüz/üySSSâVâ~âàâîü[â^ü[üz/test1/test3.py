import math

x = (1.0/3)
y = math.fmod(x,13)
print y
