num = 0xffffffffffffffffffffffffffffffff

print "%d" % num
