import math

p  = 3
print "%f" % (math.sqrt(p))
print "%d" % (math.floor(math.sqrt(p)))
