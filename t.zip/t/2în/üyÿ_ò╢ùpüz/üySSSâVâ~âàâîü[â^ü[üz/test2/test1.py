# -*- coding: sjis -*-

if __name__ == "__main__":

	file = open("config.conf", 'r')
	configList = []


	for line in file:
		line = line.replace("\n", "")
		line = line.split(":")
		configList.append(line[1])

	print configList

	file.close()

