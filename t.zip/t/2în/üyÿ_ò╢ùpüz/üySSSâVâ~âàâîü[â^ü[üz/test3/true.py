# -*- coding: sjis -*-

s = "aiueo"

a = s.isalnum()

if a:
	print "ya"
