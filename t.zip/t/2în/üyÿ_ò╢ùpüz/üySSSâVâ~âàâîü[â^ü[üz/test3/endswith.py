# -*- coding: sjis -*-

s = "python is programming laungage"

print s.endswith("python")
print s.endswith("laungage")

print ""

if s.endswith("python"):
	print s.endswith("python")

if s.endswith("laungage"):
	print s.endswith("laungage")
