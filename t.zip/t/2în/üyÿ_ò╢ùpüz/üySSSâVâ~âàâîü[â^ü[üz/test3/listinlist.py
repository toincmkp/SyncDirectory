# -*- coding: sjis -*-

if __name__ == "__main__":

	list1 = ["aiu", "eo", "kaki", "kuke", "ko"]
	list2 = ["aiu", "ko", "kaki"]
	list3 = ["aiu", "aiu"]

	if "aiu" in list1:
		print "list2 in list1"

