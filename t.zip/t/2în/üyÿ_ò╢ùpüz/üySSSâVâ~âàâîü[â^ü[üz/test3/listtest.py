# -*- coding: sjis -*-

import random

list = [1, 2, 3, 4, 5]
list2 = []

for i in list:
	list2.append(i)

print list
print list2
random.shuffle(list2)
print "----------------------------"
print "list  = ", list
print "list2 = ", list2
