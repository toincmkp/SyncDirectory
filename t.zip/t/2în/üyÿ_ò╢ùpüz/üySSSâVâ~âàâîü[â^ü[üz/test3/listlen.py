# -*- coding: sjis -*-

if __name__ == "__main__":

	list = [1, 2, 3]
	print len(list)

	list2 = []
	print len(list2)
