# -*- coding: sjis -*-

import hashlib


s = "aiueo"

print hashlib.sha1(s)
x = hashlib.sha1(s).hexdigest()

print x
