# -*- coding: sjis -*-

s = "aiu:::eo===kakikukeko"

print (((s.replace(":", "")).replace("=", ""))).isalnum()
print s
