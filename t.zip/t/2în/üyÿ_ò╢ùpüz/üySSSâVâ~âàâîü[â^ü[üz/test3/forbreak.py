# -*- coding: sjis -*-

for i in range(5):
	for j in range(3):
		if j == 1:
			break
		print "j =", j

	print "i =", i
