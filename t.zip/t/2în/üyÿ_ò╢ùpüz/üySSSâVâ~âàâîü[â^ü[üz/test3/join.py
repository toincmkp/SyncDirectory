# -*- coding: sjis -*-

a = ["a", "i", "u"]

print ":".join(a)
print a
