# -*- coding: sjis -*-

if __name__ == "__main__":

	s = "aiueo"
	x = 8

	s = s + "".join('=' for i in range(x-len(s)))

	print s
