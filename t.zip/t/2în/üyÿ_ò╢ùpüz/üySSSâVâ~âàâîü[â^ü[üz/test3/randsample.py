# -*- coding: sjis -*-

import random

list = [1, 2, 3]

temp = random.sample(list, 2)

print temp

print "---------------"

temp = random.sample(range(10), 3)

print temp
