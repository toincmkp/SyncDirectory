# -*- coding: sjis -*-

import os

if __name__ == "__main__":

	functions_path = os.getcwd()
	functions_path = functions_path.replace("\\", "/")
	functions_path = functions_path.replace("C:", "")
	functions_path = functions_path + "/functions"

	print functions_path
