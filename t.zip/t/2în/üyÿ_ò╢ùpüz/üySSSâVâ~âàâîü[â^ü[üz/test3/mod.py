# -*- coding: sjis -*-

# 4/3 �� x mod 13
# a/b �� x mod p

a = 4
b = 3
p = 13

flag = 0
i = 1
while flag != 1:
	print "i =", i

	if (b * i) % p == 1:
		flag = 1
		x = i
		print "x =", i

	i += 1

ans = (4 * x) % p

print "ans =", ans
