# coding: Shift_Jis

d = "2013:12:15"
data = d.split(":")

print data
print d


