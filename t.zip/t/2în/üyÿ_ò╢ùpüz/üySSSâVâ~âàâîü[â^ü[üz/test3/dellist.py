# -*- coding: sjis -*-

if __name__ == "__main__":

	list = [1, 2, 3]
	print len(list)

	del list[0]

	print list
	print list[0]

	list2 = [[2, 3, 4], [10, 11]]

	print "---------------"
	print list2
	del list2[0][0]
	print list2
