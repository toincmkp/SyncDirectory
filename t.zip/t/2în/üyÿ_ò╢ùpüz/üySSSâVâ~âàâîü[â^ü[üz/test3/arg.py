# -*- coding: sjis -*-

if __name__ == "__main__":

	input = "aiu 654 ee 5"

	input = input.split(" ")

	print len(input)
	print input