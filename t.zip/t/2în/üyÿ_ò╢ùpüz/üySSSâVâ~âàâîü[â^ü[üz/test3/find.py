# -*- coding: sjis -*-

s = "aiu python eio"
s2 = "feji jf geahl:"

print s.find("python")
print s2.find("python")
