# -*- coding: sjis -*-

if __name__ == "__main__":

	list = ["aiueo", "AAA"]

	s1 = "AAA"
	s2 = "iue"

	if s1 in list:
		print "s1 in list"

	if s2 in list:
		print "a"

	else:
		print "not"
