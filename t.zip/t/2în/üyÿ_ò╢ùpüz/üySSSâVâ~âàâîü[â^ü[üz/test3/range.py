# coding: Shift_Jis

for i in range(5):
	print i

for i in range(0, 5):
	print i
