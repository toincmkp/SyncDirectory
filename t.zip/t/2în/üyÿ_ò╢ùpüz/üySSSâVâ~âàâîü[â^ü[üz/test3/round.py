# -*- coding: sjis -*-

import math

if __name__ == "__main__":

	x = math.pi * 2

	y = round(x, 2)

	print x
	print y
