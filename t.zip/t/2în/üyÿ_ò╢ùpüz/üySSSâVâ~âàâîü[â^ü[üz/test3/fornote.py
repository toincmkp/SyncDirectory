# -*- coding: sjis -*-

if __name__ == "__main__":

	print "-------"

	for i in range(10, 20+1):
		print i

	print "-------"

	for i in range(10, 10+1):
		print i

	print "-------"

	for i in range(10, 10):
		print i

	print "-------"

	for i in range(10, 31, 10):
		print i
