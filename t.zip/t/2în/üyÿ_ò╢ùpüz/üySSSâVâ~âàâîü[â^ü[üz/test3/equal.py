# -*- coding: sjis -*-

s = "555"
a = (len(s) == 3)

print a
