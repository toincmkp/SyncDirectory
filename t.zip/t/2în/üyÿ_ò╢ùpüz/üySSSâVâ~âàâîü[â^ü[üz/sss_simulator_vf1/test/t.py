import time

print int(time.time())