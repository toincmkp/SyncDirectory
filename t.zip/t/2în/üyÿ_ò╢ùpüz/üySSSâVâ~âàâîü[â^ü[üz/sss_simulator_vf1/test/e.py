import os, time

for i in range(100):
	os.system("cls")
	print i, "/", "99"

	time.sleep(0.02)
