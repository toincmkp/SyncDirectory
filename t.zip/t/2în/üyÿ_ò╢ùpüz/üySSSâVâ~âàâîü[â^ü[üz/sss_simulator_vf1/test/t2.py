import random

print random.randint(0, 0)
