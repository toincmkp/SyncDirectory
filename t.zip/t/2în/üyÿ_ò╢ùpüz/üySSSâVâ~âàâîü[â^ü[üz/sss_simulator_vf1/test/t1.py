import os
import platform


if platform.system() == "Windows":
	os.system("cls")
	print platform.system()

else:
	os.system("clear")
	print platform.system()
