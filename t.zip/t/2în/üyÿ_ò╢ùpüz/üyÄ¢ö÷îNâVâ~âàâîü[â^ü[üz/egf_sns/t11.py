a = "aieuo"

dectlist = {a:[21, 54]}

print dectlist
print dectlist[a][0]

dectlist["eee"] = [99, 87]

print dectlist

dectlist2 = {}

dectlist2["ooo"] = [1, [21, 0], "aaa"]

print dectlist2

listlist = []
listlist.append(dectlist2)
listlist.append(dectlist)

print listlist
print listlist[1]["eee"]

print "---"
dectlist3 = {}
dectlist3[0x23] = [123, 654]

print dectlist3[35]