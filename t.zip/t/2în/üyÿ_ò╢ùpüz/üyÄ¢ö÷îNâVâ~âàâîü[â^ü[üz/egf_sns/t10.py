import sys
import time

a = ["-----", "-----", "-----", ">----", "->---", "-->--", "--->-", "---->"]

for i in range(100):
	sys.stdout.write("\r[")
	sys.stdout.write(a[i % len(a)])
	sys.stdout.write("]")
	time.sleep(0.1)

sys.stdout.write("\r")
sys.stdout.write("[*>_<*]")