# -*- coding: sjis -*-

import math

def CalcCommonPoints(p1, p2, radius):
	a = p1[0]
	b = p1[1]
	c = p2[0]
	d = p2[1]

	# �~���S��v
	if a == c and b == d:
		return [[-1, -1], [-1, -1]]

	# X���W�ň�v
	if a == c:
		y = float(d**2 - b**2) / (-2*b + 2*d)

		l = 1
		m = -2 * a
		n = a**2 + y**2 - 2 * b * y + b**2 - radius**2

		# ��ڂ̌�_(����)
		q = float(-m - math.sqrt(m**2 - 4 * l * n)) / (2 * l)
		s = y

		# ��ڂ̌�_(�E��)
		r = float(-m + math.sqrt(m**2 - 4 * l * n)) / (2 * l)
		t = y

		return [[int(q), int(s)], [int(r), int(t)]]

	# Y���W�ň�v
	elif b == d:
		x = float(c**2 - a**2) / (-2*a + 2*c)

		l = 1
		m = -2 * b
		n = b**2 + x**2 - 2 * a * x + a**2 - radius**2

		# ��ڂ̌�_(����)
		q = x
		s = float(-m - math.sqrt(m**2 - 4 * l * n)) / (2 * l)

		# ��ڂ̌�_(�㑤)
		r = x
		t = float(-m + math.sqrt(m**2 - 4 * l * n)) / (2 * l)

		return [[int(q), int(s)], [int(r), int(t)]]

	# �ʏ폈��
	else:
		alpha = (-2 * a) + 2 * c
		beta = (-2 * b) + 2 * d
		gamma = (-a**2) + c**2 - b**2 + d**2

		e = float(-alpha) / beta
		f = float(gamma) / beta

		l = 1 + e**2
		m = (-2 * c) + 2*e*f - 2*d*e
		n = c**2 + f**2 - 2*d*f + d**2 - radius**2

		# ��ڂ̌�_(����)
		q = float(-m - math.sqrt(m**2 - 4 * l * n)) / (2 * l)
		s = e * q + f

		# ��ڂ̌�_(�E��)
		r = float(-m + math.sqrt(m**2 - 4 * l * n)) / (2 * l)
		t = e * r + f

		return [[int(q), int(s)], [int(r), int(t)]]


if __name__ == "__main__":
	a = CalcCommonPoints([425, 532], [425, 500], 250)

	print a