a = [1, 2, 13]

for i in range(len(a)):
	print i