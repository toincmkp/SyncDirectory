
"""
dlist = [[1, 2], [1, 2], 2, 3]
print dlist
dlist = list(set(dlist))
print dlist
"""

dlist = [1, 1, 2, 3]
print dlist
dlist = list(set(dlist))
print dlist