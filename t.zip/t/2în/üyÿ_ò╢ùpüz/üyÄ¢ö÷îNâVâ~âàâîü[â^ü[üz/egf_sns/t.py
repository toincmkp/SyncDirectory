s = "abcdefghi"
print s.find("c")
print s.find("x")

flag = 0
i = 0
while ~flag:
	print flag
	if i == 10:
		flag = -1

	i += 1