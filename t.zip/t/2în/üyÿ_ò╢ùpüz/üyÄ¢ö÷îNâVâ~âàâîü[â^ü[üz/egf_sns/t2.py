# coding: Shift_Jis

a = [3, 5, 2, 6, 8]
b = []
print a

b.append(a.pop())
print "a =", a
print "b =", b