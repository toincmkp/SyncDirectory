import math

sales1 = [[10, 5], [5, -5]]

for i in sales1:
	i.sort()

print sales1

print math.pi

a = {}

print len(a)


b = []

for j in b:
	print j
