a = [1, 2, 3]

for i in range(1, len(a)):
	print a[i]