list = [1, 2, 3]

print list
del list[1]
print list