def u1(seq):
    new_list = []
    for item in seq:
        if item not in new_list:
            new_list.append(item)
    return new_list

if __name__ == "__main__":

	dlist = [[1, 2], [1, 2], 2, 3]
	udlist = u1(dlist)

	print udlist