# -*- coding: sjis -*-

# ---------------------------------------------------------------------------------------------------------
# Import

import math
import random


# ---------------------------------------------------------------------------------------------------------
# Define
TOTALNODE    = 0
MAPSIZEX     = 1
MAPSIZEY     = 2
RADIUS       = 3
MAXSPEED     = 4
MAXWAIT      = 5
MAXKHRONOS   = 6
ONEFRAME     = 7
HELLOPERIOD  = 8
TRIALS       = 9
SFCHECK      = 10

PACKET_SEND_TIME = 0
PACKET_RECV_TIME = 1
PACKET_SEND_BITE = 0
PACKET_RECV_BITE = 1

ID_LENGTH = 4


# ---------------------------------------------------------------------------------------------------------
# Classes

class node_class:

	def __init__(self):
		self.id = "NaN"
		self.location = []
		self.dest_location = []
		self.speed = -1
		self.direction = -1
		self.wait = -1
		self.hello_buffer = []
		self.packet_sr_times = [0, 0]
		self.packet_sr_bites = [0, 0]
		self.hello_timing = -1
		self.packet_quere = []

	def move(self, one_frame):
		self.location[0] = int(self.location[0] + (one_frame * self.speed * math.cos(self.direction)))
		self.location[1] = int(self.location[1] + (one_frame * self.speed * math.sin(self.direction)))
		self.direction = math.atan2((self.dest_location[1] - self.location[1]), (self.dest_location[0] - self.location[0]))


# ---------------------------------------------------------------------------------------------------------
# Functions

def NodeCreate(Node_List, Config_List):

	for i in range(0, Config_List[TOTALNODE]):
		Node_List.append(node_class())

	for i in Node_List:
		i.id = "".join(random.choice('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') for j in range(ID_LENGTH))
		for k in Node_List:
			if k != i and k.id == i.id:
				while 1:
					i.id = "".join(random.choice('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') for j in range(ID_LENGTH))
					if k.id != i.id:
						break
				break

		i.location.append(random.randint(0, Config_List[MAPSIZEX]))
		i.location.append(random.randint(0, Config_List[MAPSIZEY]))

		i.dest_location.append(random.randint(0, Config_List[MAPSIZEX]))
		i.dest_location.append(random.randint(0, Config_List[MAPSIZEX]))

		i.speed = random.randint(0, Config_List[MAXSPEED])

		i.direction = math.atan2((i.dest_location[1] - i.location[1]), (i.dest_location[0] - i.location[0]))

		i.wait = random.randint(0, Config_List[MAXWAIT])

		i.hello_timing = random.randint(0, Config_List[HELLOPERIOD])

def SD_node_init(Node_List, Config_List):
	Node_List[0].location[0] = 0
	Node_List[0].location[1] = 0
	Node_List[0].dest_location[0] = Config_List[MAPSIZEX]
	Node_List[0].dest_location[1] = Config_List[MAPSIZEY]
	Node_List[0].wait = Config_List[MAXKHRONOS] + 1
	Node_List[1].location[0] = Config_List[MAPSIZEX]
	Node_List[1].location[1] = Config_List[MAPSIZEY]
	Node_List[1].dest_location[0] = 0
	Node_List[1].dest_location[1] = 0
	Node_List[1].wait = Config_List[MAXKHRONOS] + 1

def NodeInformation(Node_List):
	for i in Node_List:
		print i.id, i.location, i.dest_location


def main():
	print "\n-------------------------------------"
	print "           Configuration"
	print "-------------------------------------"

	Config_List = []
	file = open("config.conf", 'r')

	for line in file:
		line = line.replace("\n", "")
		print line
		line = line.split(":")

		if line[1].find("-") != -1:
			temp = line[1].split("-")
			temp[0] = int(temp[0])
			temp[1] = int(temp[1])
			Config_List.append(temp)

		else:
			Config_List.append(int(line[1]))

	file.close()

	print "\n-------------------------------------"
	print "   Configration check is complete!"
	print "-------------------------------------"
	print "Start? (y/n)\n"
	print "(EGF-SNS) >",

	temp = raw_input()

	if temp != "y":
		print "bye!"
		exit()

	Node_List = []
	NodeCreate(Node_List, Config_List)
	SD_node_init(Node_List, Config_List)

	print "\n-------------------------------------"
	print "   Node Initialization"
	print "-------------------------------------"

	NodeInformation(Node_List)

	Kronos = 0
	while Kronos < Config_List[MAXKHRONOS]:


		# [Node Moving]
		for i in Node_List:
			if i.wait < Kronos:
				i.move(Config_List[ONEFRAME])

			temp = i.speed * Config_List[ONEFRAME]

			if math.fabs(i.dest_location[0] - i.location[0]) < temp and math.fabs(i.dest_location[1] - i.location[1]) < temp:
				i.dest_location[0] = random.randint(0, Config_List[MAPSIZEX])
				i.dest_location[1] = random.randint(0, Config_List[MAPSIZEY])
				i.direction = math.atan2((i.dest_location[1] - i.location[1]), (i.dest_location[0] - i.location[0]))
				i.speed = random.randint(0, Config_List[MAXSPEED])
				i.wait = Kronos + random.randint(0, Config_List[MAXWAIT])

		# [One Frame Ending]
		Kronos += Config_List[ONEFRAME]




# ---------------------------------------------------------------------------------------------------------
if __name__ == "__main__":

	main()

# ---------------------------------------------------------------------------------------------------------
# [�i��]


# ---------------------------------------------------------------------------------------------------------