a = float(5) / 2

print a