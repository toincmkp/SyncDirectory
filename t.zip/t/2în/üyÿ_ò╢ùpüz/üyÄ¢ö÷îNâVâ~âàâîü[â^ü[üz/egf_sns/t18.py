a = 0
b = 1
c = 0
d = "in"

if a or (b and c):
	print d

if (a or b) and c:
	print d