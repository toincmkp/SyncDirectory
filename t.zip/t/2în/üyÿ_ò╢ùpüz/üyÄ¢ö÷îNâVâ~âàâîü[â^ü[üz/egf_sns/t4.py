s = "abcdefghi"
print len(s)
print s.find("c")
print s.find("x")
print s[2:5]
print s[:4]
print s[2:]