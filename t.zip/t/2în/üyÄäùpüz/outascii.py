# -*- coding: sjis -*-

import random

if __name__ == "__main__":

	input_data = raw_input()

	if len(input_data) == 1:
		print hex(ord(input_data)), ": %d :" % ord(input_data),
		print bin(ord(input_data))

	else:
		print "Input a letter."
