# -*- coding: sjis -*-

# ------------------------------------------------------------
# xor�ɂ��t�@�C���̈Í����v���O����
# 00��xor�ɂ��ω��̂Ȃ��Í������ł��邾�����Ȃ����邽�߂�
# ���s�R�[�h�̒����̂��߂ɉ��x��base64�����܂��Ă�
# �g�p���@��usage:�Q��
# ------------------------------------------------------------

import sys, base64



def process_e(argvs):

	f1 = open(argvs[2], 'rb')

	allLine = f1.read()
	tempdata = base64.b64encode(allLine)

	if check_file_and_key_length(len(tempdata), len(argvs[3])):
		f1.close()
		exit()

	f2 = open("encoding_data", 'w')
	f2.write(base64.b64encode(sxor(tempdata, argvs[3])))

	f1.close()
	f2.close()


def process_d(argvs):

	f1 = open(argvs[2], 'rb')

	tempdata = f1.read()

	if check_file_and_key_length(len(tempdata), len(argvs[3])):
		f1.close()
		exit()

	s = sxor(base64.b64decode(tempdata), argvs[3])
	print base64.b64decode(s)

	f2 = open("decoding_data", 'w')
	f2.write(base64.b64decode(s))

	f1.close()
	f2.close()




def sxor(s1,s2):

    if len(s1) < len(s2):
        q = len(s2) / len(s1)
        r = len(s2) % len(s1)

        if r == 0:
            s1 = s1 * q

        else:
            s0 = s1
            s1 = s1 * q

            for i in range(0, r):
                s1 = s1 + (s0[i])

    if len(s1) > len(s2):
        q = len(s1) / len(s2)
        r = len(s1) % len(s2)

        if r == 0:
            s2 = s2 * q

        else:
            s0 = s2
            s2 = s2 * q

            for i in range(0, r):
                s2 = s2 + (s0[i])

    return ''.join(chr(ord(a) ^ ord(b)) for a,b in zip(s1,s2))


def check_file_and_key_length(file_length, key_length):

	if file_length < key_length:
		print "error: File length is less than the key!"

		return 1

	return 0



if __name__ == "__main__":

	argvs = sys.argv
	argc = len(argvs)

	if argc != 4:
		print "\nUsage : python2 filexor.py option[-e or -d] input_file_name key"
		exit()

	if argvs[1] == "-e":
		process_e(argvs)

	elif argvs[1] == "-d":
		process_d(argvs)

	else:
		print "error:"

