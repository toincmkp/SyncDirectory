# coding: Shift_JIS

import sys, random, time

argvs = sys.argv

if len(argvs) != 2:
	print "usage : python2 bin_hex.py ��萔"
	exit()

for i in range(int(argvs[1])):
	num = random.randint(1, 15)

	print "bin =",

	sbin = str(bin(num)).replace("0b", "")

	if len(sbin) == 1:
		print "000" + sbin

	elif len(sbin) == 2:
		print "00" + sbin

	elif len(sbin) == 3:
		print "0" + sbin

	else:
		print sbin

	time.sleep(1)

	print "hex = " + str(hex(num)).replace("0x", "")
	print "----------"
	time.sleep(0.5)