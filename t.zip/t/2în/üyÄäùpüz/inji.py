# -*- coding: sjis -*-

import random

if __name__ == "__main__":

	for i in range(0x30, 0x80):
		print "i = %x : %c" % (i, chr(i))
