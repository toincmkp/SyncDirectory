# coding: Shift_JIS
 
import sys
import os
 
argvs = sys.argv

if len(argvs) != 2:
	print "usage : python2 hex2txt.py hex_strings"
	exit()

hexs = argvs[1]
s = hexs
if len(hexs) % 2 == 1:
	temps = hexs[:(len(hexs) - 1)]
	lastc = hexs[len(hexs) - 1]
	s = temps + "0" + lastc

templist = []
for i in range(len(s)):
	if i % 2 == 0:
		templist.append("\\x")

	templist.append(s[i])

sf = "".join(templist)
print ""
print sf

cmd = "python2 -c \"print \'" + sf + "\'\""
os.system(cmd)