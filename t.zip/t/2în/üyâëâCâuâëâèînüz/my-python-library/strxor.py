import sys

if len(sys.argv) <= 2:
	print "usage:"
	print "python2 strxor.py hex str"
	exit(1)

xordata = ""
num = sys.argv[1].decode("hex")

for c in sys.argv[2]:
	xordata += chr(ord(c) ^ ord(num))

sys.stdout.write(xordata)

