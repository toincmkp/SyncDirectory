# -*- coding:sjis -*-

# ------------------------------------------------
# usage :
# python2 saesar.py str shift
# ------------------------------------------------

import sys
import string

def caesar(plaintext, shift):
	alphabet = string.ascii_lowercase
	shifted_alphabet = alphabet[shift:] + alphabet[:shift]
	table = string.maketrans(alphabet, shifted_alphabet)
	plaintext = plaintext.translate(table)
	alphabet = string.ascii_uppercase
	shifted_alphabet = alphabet[shift:] + alphabet[:shift]
	table = string.maketrans(alphabet, shifted_alphabet)

	return plaintext.translate(table)


if __name__ == '__main__':

	if len(sys.argv) <= 2:
		print "usage:"
		print "    python2 caesar.py str shift"
		exit(1)

	print caesar(sys.argv[1], int(sys.argv[2]))
