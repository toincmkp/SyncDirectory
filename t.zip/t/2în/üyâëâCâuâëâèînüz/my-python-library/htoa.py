import sys

if len(sys.argv) != 2:
	print "usage:"
	print "python2 htoa.py hex"
	exit(1)

print sys.argv[1].decode("hex")
