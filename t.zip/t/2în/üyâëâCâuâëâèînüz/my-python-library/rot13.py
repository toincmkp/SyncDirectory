# -*- coding:sjis -*-

# ------------------------------------------------
# usage :
# python2 rot13.py str
# ------------------------------------------------

import sys
import string

def rot13(s):
	_rot13 = string.maketrans( 
		"ABCDEFGHIJKLMabcdefghijklmNOPQRSTUVWXYZnopqrstuvwxyz", 
		"NOPQRSTUVWXYZnopqrstuvwxyzABCDEFGHIJKLMabcdefghijklm")
	return string.translate(s, _rot13)


if __name__ == '__main__':

	if len(sys.argv) <= 1:
		print "usage:"
		print "    python2 rot13.py str"
		exit(1)

	print rot13(sys.argv[1])
