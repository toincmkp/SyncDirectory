# ------------------------------------------------
# usage  : 
#     python2 morus.py [option] [str or filename]
#     option : -e -d -f
#
#     ex.)
#         -d ".--- -.-"
#         -f [file]
#
#     other.)
#         -f option can use a morus file.
# ------------------------------------------------

import sys

morus_en_dict = {
	"a" : ".-",
	"b" : "-...",
	"c" : "-.-.",
	"d" : "-..",
	"e" : ".",
	"f" : "..-.",
	"g" : "--.",
	"h" : "....",
	"i" : "..",
	"j" : ".---",
	"k" : "-.-",
	"l" : ".-..",
	"m" : "--",
	"n" : "-.",
	"o" : "---",
	"p" : ".--.",
	"q" : "--.-",
	"r" : ".-.",
	"s" : "...",
	"t" : "-",
	"u" : "..-",
	"v" : "...-",
	"w" : ".--",
	"x" : "-..-",
	"y" : "-.--",
	"z" : "--..",
	" " : " ",
	"." : ".-.-.-",
	"0" : "-----",
	"1" : ".----",
	"2" : "..---",
	"3" : "...--",
	"4" : "....-",
	"5" : ".....",
	"6" : "-....",
	"7" : "--...",
	"8" : "---..",
	"9" : "----."
}

morus_de_dict = {
	".-"     : "a",
	"-..."   : "b",
	"-.-."   : "c",
	"-.."    : "d",
	"."      : "e",
	"..-."   : "f",
	"--."    : "g",
	"...."   : "h",
	".."     : "i",
	".---"   : "j",
	"-.-"    : "k",
	".-.."   : "l",
	"--"     : "m",
	"-."     : "n",
	"---"    : "o",
	".--."   : "p",
	"--.-"   : "q",
	".-."    : "r",
	"..."    : "s",
	"-"      : "t",
	"..-"    : "u",
	"...-"   : "v",
	".--"    : "w",
	"-..-"   : "x",
	"-.--"   : "y",
	"--.."   : "z",
	" "      : " ",
	".-.-.-" : ".",
	"-----"  : "0",
	".----"  : "1",
	"..---"  : "2",
	"...--"  : "3",
	"....-"  : "4",
	"....."  : "5",
	"-...."  : "6",
	"--..."  : "7",
	"---.."  : "8",
	"----."  : "9"
}

def usage():
	if len(sys.argv) != 3:
		print "usage :"
		print "    python2 morus.py [option] [str]"
		exit(1)

	if (sys.argv[1] == "-e" or sys.argv[1] == "-d" or sys.argv[1] == "-f") == 0:
		print "usage :"
		print "    morus.py needs -e, -d or -f option."
		exit(1)

def main():
	usage()

	if sys.argv[1] == "-e":
		encode_data = ""

		for c in sys.argv[2]:
			if c != " ":
				encode_data += morus_en_dict[c]
				encode_data += " "

			else:
				encode_data += morus_en_dict[c]

		print encode_data

	elif sys.argv[1] == "-d":
		decode_data = ""

		morus_data = sys.argv[2].split(" ")
		for m in morus_data:
			if m == "":
				decode_data += " "

			else:
				decode_data += morus_de_dict[m]

		print decode_data

	else:
		f = open(sys.argv[2], 'r')

		for line in f:
			decode_data = ""

			line = line.replace("\n", "")
			morus_data = line.split(" ")
			for m in morus_data:
				if m == "":
					decode_data += " "

				else:
					decode_data += morus_de_dict[m]

			print decode_data

		f.close()

if __name__ == '__main__':

	main()
