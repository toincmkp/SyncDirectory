import sys

if len(sys.argv) <= 2:
	print "usage:"
	print "python2 strxor.py hex [file]"
	exit(1)

f1 = open(sys.argv[2], "rb")
bdata = f1.read()

xordata = ""
num = sys.argv[1].decode("hex")

for c in bdata:
	xordata += chr(ord(c) ^ ord(num))

f2 = open("filexor_output.bin", "wb")
f2.write(xordata)
print "filexor Success! -> filexor_output.bin"

f1.close()
f2.close()