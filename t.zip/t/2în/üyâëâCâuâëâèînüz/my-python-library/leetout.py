# ------------------------------------------------
# usage:
#     python2 leetout.py str
# ------------------------------------------------

import sys
from string import maketrans

def main():
	if len(sys.argv) <= 1:
		print "usage:"
		print "    python2 leetout.py str"
		exit(1)

	intab  = "ABEIOST"
	outtab = "4831057"
	trantab = maketrans(intab, outtab)

	s = sys.argv[1]
	s = s.upper()

	print s.translate(trantab)

if __name__ == '__main__':

	main()
