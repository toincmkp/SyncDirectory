dict_c = {}
sentence = """
ke12buyuuuuuuciuuuv8uuuuhqcuuwouuuuvuwuuuquuuisxukuuuuuuuuuuuuuuuuuuuuuuuux/
uux/uux/uuuuuuuu/0dbohiuqpoisfayzmwz6qzugtgnaatgdevgtauagtedjulruslwdtcuuuuu
"""

for c in sentence:
	dict_c[c] = 0

for c in sentence:
	dict_c[c] += 1

for k, v in sorted(dict_c.items(), key=lambda x:x[1]):
	print k, v