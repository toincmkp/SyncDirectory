# -*- coding: sjis -*-
# ------------------------------------------------
# �񕶐��̔���֐�
# ------------------------------------------------

def isPalindromic_n(n):
	temp1 = ""
	temp2 = str(n)

	for c in reversed(temp2):
		temp1 += c

	if temp1 == temp2:
		return 1

	return 0

if __name__ == "__main__":

	count = 0

	for i in range(1, 10001):
		if isPalindromic_n(i):
			count += 1

	print count
