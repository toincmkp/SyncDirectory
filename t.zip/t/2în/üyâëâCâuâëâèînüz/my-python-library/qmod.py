# -*- coding: sjis -*-

# ------------------
# qmod(a, b, p)
# �Ԃ�l�ɓ�����Ԃ�
# a,b��-�̒l�ł�����
# 
# ��:
# 4/3 �� x mod 13
# a/b �� x mod p
# x = qmod(a, b, p)
# ------------------


def qmod(a, b, p):
	flag = 0
	i = 1

	if b < 0:
		b = b * -1
		a = a * -1

	while flag != 1:
		if (b * i) % p == 1:
			flag = 1
			x = i

		i += 1

		if i == p:
			return -1

	ans = (a * x) % p

	return ans


if __name__ == "__main__":

	x = qmod(4, 2, 13)
	print x
