import random, sys

list = [9, 12, 8, 14, 11]

str = """
XXXXXXX X XX XXX X X  XXXXXXX
X     X   X X  X XX   X     X
X XXX X XXX XX   X X  X XXX X
X XXX X    X   XX X X X XXX X
X XXX X    XX  XX   X X XXX X
X     X X XXXXX XXX X X     X
XXXXXXX X X X X X X X XXXXXXX
             X    XX         
X X   XX X XXX XXX X   X  X X
X X XX X X      XXX XX X X X 
   X  X X XXXXX XXXX   X XX X
 X XX   XXXXX XXX X  XX XX XX
X  X  X XXX  XX    X  XX XXXX
   X      X XXX  X  XX X X   
 X X XX        X   X     X  X
XXXX X  XX XXX    X XXXX X   
 X XX XX XXXXX XX   X X   X  
 XX XX      X   X   XX   XX  
XXXXXXXXX   XXX X XX XXXX   X
  X XX  XXX X XXX        X  X
XX   XX   XX XX  XXXXXXXX XXX
        XXX XXX  X XX   XXX  
XXXXXXX XXXX   X    X X X   X
X     X     XX   X  X   XX XX
X XXX X     XX XXX XXXXXXX X 
X XXX X  XX  X  X  X   X  XX 
X XXX X XX   XX XXXXX   XXXXX
X     X  XX  XXXX X XX X X   
XXXXXXX X X      XX XX  X   X
"""

for c in str:
	if c == "\n":
		i = 0
		num = list[i%4]
		print ""

	if i < num:
		sys.stdout.write(" ")

	else:
		sys.stdout.write(c)

	i += 1