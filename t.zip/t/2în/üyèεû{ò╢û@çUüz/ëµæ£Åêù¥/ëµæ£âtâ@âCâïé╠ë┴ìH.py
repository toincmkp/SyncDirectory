# coding: Shift_Jis

import Image


img = Image.open("C:\Users\yosuke\�yPrograming�z\�yPython�z\logo.jpg")

left_right_image = img.transpose(Image.FLIP_LEFT_RIGHT)
left_right_image.save("C:\Users\yosuke\�yPrograming�z\�yPython�z\logo_left_right.jpg")

img.thumbnail((125,25))
img.save("C:\Users\yosuke\�yPrograming�z\�yPython�z\logo_thum.jpg")
