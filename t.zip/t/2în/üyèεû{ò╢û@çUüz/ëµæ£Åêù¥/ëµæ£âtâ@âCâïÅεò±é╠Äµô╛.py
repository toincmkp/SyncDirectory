# coding: Shift_Jis

import Image

img = Image.open("C:\Users\yosuke\�yPrograming�z\�yPython�z\logo.jpg")

print img.format
print img.size
print img.mode
