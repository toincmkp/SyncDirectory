# coding: Shift_Jis

import Image


img = Image.open("C:\Users\yosuke\�yPrograming�z\�yPython�z\logo.jpg")

img.save("c:/python27/copy.jpg")
img.save("c:/python27/logo.bmp","bmp")
img.save("c:/python27/logo.gif","gif")
