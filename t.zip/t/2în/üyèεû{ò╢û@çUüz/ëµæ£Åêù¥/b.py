import Image

img = Image.open("logo.jpg")

print img.format
print img.size
print img.mode
