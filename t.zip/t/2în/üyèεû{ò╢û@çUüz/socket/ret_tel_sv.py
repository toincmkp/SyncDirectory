# -*- coding: sjis -*-

import socket, sys



if __name__ == '__main__':

	HOST = "192.168.43.32"
	PORT = 7890

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.bind((HOST, PORT))
	s.listen(1)
	soc, addr = s.accept()

	print "Conneted by", addr

	while 1:

		dat = soc.recv(1024)
		sys.stdout.write(dat)

#		data = "success!"
#		soc.send(data)

		if dat == "q":
			data = "success!"
			soc.send(data)
			break

	s.close()
	soc.close()
