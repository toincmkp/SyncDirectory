# -*- coding: sjis -*-

import socket


if __name__ == '__main__':

	HOST = "localhost"
	PORT = 7890

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.connect((HOST, PORT))

	while 1:
		data = s.recv(1024)
		print data

		data = raw_input()
		if data == "q":
			break

	s.close()
