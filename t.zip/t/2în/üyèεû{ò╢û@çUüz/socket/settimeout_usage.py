import socket

if __name__ == '__main__':

	HOST = "192.168.43.32"
	PORT = 789

	s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	s.bind((HOST, PORT))
	s.listen(5)

	i = 0
	while i < 2:
		soc, addr = s.accept()
		soc.settimeout(5)
		soc.send("Hello\n")
		rdata = soc.recv(128)

		print "Bye!"
		soc.close()

		i += 1

	s.close()