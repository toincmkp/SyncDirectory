import sys, dpkt, socket

filename = "secretmsg.pcap"
pcr = dpkt.pcap.Reader(open(filename,'rb'))
frame_counter = 0

for ts, buf in pcr:
	eth = dpkt.ethernet.Ethernet(buf)
	ip = eth.data
	trs = ip.data

	src_a = socket.inet_ntoa(ip.src)
	dst_a = socket.inet_ntoa(ip.dst)

	frame_counter += 1

#	---------------------------------------------------------------
#	if frame_counter > 1:
#		print "%d: %f %f" % ( frame_counter, ts, ts - last_time )

#	last_time = ts
#	---------------------------------------------------------------
#	if ip.src == chr(10)+chr(1)+chr(9)+chr(3):
#	---------------------------------------------------------------
#	source_port = trs.sport
#	dest_port = trs.dport
#	---------------------------------------------------------------
#	if ord(buf[0x17]) == 17:
#		sys.stdout.write(buf[0x2a])
#	---------------------------------------------------------------

	print "No: %d  Time: %f  src: %14s  dst: %s" % (frame_counter, ts, src_a, dst_a)




