# -*- coding: sjis -*-

import os

if __name__ == "__main__":

	functions_path = os.getcwd()

	print functions_path
