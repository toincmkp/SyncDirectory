str = "This is an apple."

for i in str:
	print i