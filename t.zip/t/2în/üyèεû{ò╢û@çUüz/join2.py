list = [61, 65, 70, 100]

print "".join(chr(c) for c in list)
