# coding: Shift_Jis

input = raw_input()
print int(input) * 2

while 1:
	input2 = raw_input()
	print int(input2) * 3

	if int(input2) > 50:
		break
