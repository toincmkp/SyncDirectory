# coding: Shift_Jis

import subprocess

p1 = subprocess.Popen("python2 w.py".split(" "), shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE)

stri = ""
for i in range(100):
	stri = stri + str(i) + "\n"

print p1.communicate(stri)[0]
