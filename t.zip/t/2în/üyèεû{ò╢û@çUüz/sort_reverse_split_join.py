# sort_reverse_split_join

sales1 = [50, 100, 80, 45]

sales1.sort()
print sales1

sales2 = [50, 100, 80, 45]

sales2.reverse()
print sales2

sales3 = [50, 100, 80, 45]

sales3.sort()
sales3.reverse()
print sales3

# ������ƃ��X�g�̑��ݕϊ�

d = "2013/12/15"
print d.split("/")

a = ["a", "b", "c"]
print ".".join(a)
