import textwrap

doc = """aiueo to wowowo
kakiku ieieie
saasisus fofo too
"""

print textwrap.fill(doc, width = 8)