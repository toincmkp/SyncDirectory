from bs4 import BeautifulSoup

ex_html_text = """
<html>
    <head><title>example Python html</title></head>
    <body><h1>Hello Python!</h1><h1>Hello Python!</h1></body>
</html>
"""

ex_html_bs = BeautifulSoup(ex_html_text)
print ex_html_bs.find_all("h1")

