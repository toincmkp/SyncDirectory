# math, random

import math, random


print math.ceil(5.3)

print random.random()

