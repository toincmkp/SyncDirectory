import time, sys

print "start"

for i in range(10):
	sys.stdout.write(str(i) + "\r")
	time.sleep(1)

print "end"
