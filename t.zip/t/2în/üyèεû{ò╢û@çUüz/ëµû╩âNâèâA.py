import os

os.system("cls")

