import os

os.system("dir")

