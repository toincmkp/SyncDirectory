# -*- coding: Shift_Jis -*-

# -------------------------
# ��Fdir | python2 �p�C�v�̓���.py
# -------------------------

import sys

if __name__ == "__main__":

    all_lines = sys.stdin.read()
    print all_lines
