aiu = "irRfafajf"

print aiu.startswith("irR")
print aiu.startswith("dirR")