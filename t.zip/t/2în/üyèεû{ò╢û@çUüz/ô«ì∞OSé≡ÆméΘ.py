import platform


print platform.system()
