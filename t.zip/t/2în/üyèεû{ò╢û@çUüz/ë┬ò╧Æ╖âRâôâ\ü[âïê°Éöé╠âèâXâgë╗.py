# -*- coding: sjis -*-

import sys

argvs = sys.argv[0:]

print argvs
