# -*- coding: sjis -*-
# �K��v�Z

import math

x = math.factorial(4)
print "math.factorial(4) =", x

