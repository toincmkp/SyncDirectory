# -*- coding: sjis -*-

import base64

def sxor(s1,s2):
	return ''.join(chr(ord(a) ^ ord(b)) for a,b in zip(s1,s2))

data1 = "bX2a:==795981:==344219:===29769"
data2 = "0:iyMg:===3:===5:9359:===1:bX2a"

data3 = "iyMg:==575149:==840430:===28965"

encoding_data = base64.b64encode(sxor(data1, data2))

decoding_data = base64.b64decode(encoding_data)

a = sxor(data1, decoding_data)
b = sxor(data3, decoding_data)

k = "iyMg"
l = "bX2a"

if a.endswith(k):
	print "a i"

if a.endswith(l):
	print "a year"

if b.endswith(k):
	print "b i"

if b.endswith(l):
	print "b year"
