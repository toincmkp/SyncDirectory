import time

print "start", time.ctime()

time.sleep(1.5)

print "end  ", time.ctime()
