k = 100
sum = 0

for i in range(0, k-1):
	for j in range(i+1, k):
		print i, "-", j
		sum += 1

print sum