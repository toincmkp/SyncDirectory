import winsound
# Play Windows exit sound.
winsound.PlaySound("SystemExit", winsound.SND_ALIAS)
winsound.PlaySound('SystemExclamation', winsound.SND_ALIAS)
winsound.PlaySound('SystemAsterisk', winsound.SND_ALIAS)
winsound.PlaySound('SystemHand', winsound.SND_ALIAS)
winsound.PlaySound('SystemQuestion', winsound.SND_ALIAS)