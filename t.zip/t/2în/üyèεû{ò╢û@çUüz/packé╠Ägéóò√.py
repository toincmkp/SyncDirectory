from struct import pack

s = pack("H", 16705)
print s

r = "\x42\x43"
print r