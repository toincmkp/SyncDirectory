# coding: Shift_Jis

a = [3, 5, 2, 6, 8]
print a

a.append(13)
print a

a.pop()
print a

b = []
b.append("str")
print b
