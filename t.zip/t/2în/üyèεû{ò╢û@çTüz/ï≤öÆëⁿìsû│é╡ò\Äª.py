import sys

sys.stdout.write("hello")
sys.stdout.write("hello")
sys.stdout.write("hello")
