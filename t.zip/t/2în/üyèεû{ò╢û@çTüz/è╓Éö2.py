# -*- coding: sjis -*-
# �߂�l�Ƀ��X�g��Ԃ�

def test(n):

    list = []

    for i in range(0, n):
        list.append(i)

    return list


if __name__ == "__main__":

    temp = test(5)

    print temp
