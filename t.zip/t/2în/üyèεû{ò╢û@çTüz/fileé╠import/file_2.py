def hello():
	print "Hi!"

