# -*- coding: sjis -*-

import sys
import file_2

sys.path.append('/Users/yosuke/�yPrograming�z/�yPython�z/�y��{���@�z/file��import/dir')

import file_3


import file_3

print "start"

file_2.hello()

print "next\n"

file_3.hello()

print "end"