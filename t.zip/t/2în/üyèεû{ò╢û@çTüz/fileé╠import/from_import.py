from math import sin

print sin(2)
