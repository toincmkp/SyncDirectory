import file_2

print "start"

file_2.hello()

print "end"