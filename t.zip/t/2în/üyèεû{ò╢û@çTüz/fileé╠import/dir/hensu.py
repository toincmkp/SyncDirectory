global x

print x

x = 5
