def hello():
	print "HiHi!"

