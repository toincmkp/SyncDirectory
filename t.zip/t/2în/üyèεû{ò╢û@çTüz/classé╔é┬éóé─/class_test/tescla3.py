# -*- coding: sjis -*-

class node_class:

	def __init__(self):
		self.id = -1

	def func(self, num):
		num = num * self.id
		print num


if __name__ == "__main__":

	node = node_class()

	node.func(5)

