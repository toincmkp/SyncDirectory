# -*- coding: sjis -*-

class node_class:

  def __init__(self, id, name):
    self.id = id
    self.name = name

    self.list1 = []
    self.temp = -1

  def func(self, num):
    print num * 2
    print self.name * num

  def func2(self, num):
    list = []

    for i in range(0, num):
      list.append(self.id)

    self.list1.append(99)

    return list


def function():
  print nodeList[0].name


if __name__ == "__main__":

  print "----\n�J�n\n----\n"

  nodeList = []

  for i in range(0, 10):
    x = 0x41 + i
    nodeList.append(node_class(i, chr(x)))

  for i in range(0, 10):
    nodeList[i].func(3)

  print "---------------\n"

  temp = nodeList[2].func2(3)

  print temp

  print "----------------------"
  function()

  print "-^-^-^-^-"
  print nodeList[2].list1[0]

  print "________"
  print nodeList[0].temp
