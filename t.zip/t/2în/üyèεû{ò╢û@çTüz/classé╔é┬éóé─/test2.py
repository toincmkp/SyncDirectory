# -*- coding: sjis -*-
# �N���X��b

class test_class:

    def __init__(self, code, name):
       self.code = code
       self.name = name

if __name__ == "__main__":

    classList = []
    classList.append(test_class(1,"�e�X�g�P"))
    classList.append(test_class(2,"�e�X�g�Q"))

    """
    for value in classList:
        print "===== class ====="
        print "code --> " + str(value.code)
        print "name --> " + value.name
    """

    print "code --> " + str(classList[0].code)
    print "name --> " + classList[0].name

    print "code --> " + str(classList[1].code)
    print "name --> " + classList[1].name
