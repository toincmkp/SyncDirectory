﻿# -*- coding: utf-8 -*-

# utf-8で扱いたい場合以下の要領
#   上記に# -*- coding: utf-8 -*-
#   utf-8で文字コード指定保存
#   表示はu"～"


print u"あいうえお"
