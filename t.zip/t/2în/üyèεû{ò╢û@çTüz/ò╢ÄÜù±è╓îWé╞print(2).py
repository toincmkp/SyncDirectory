# ������֌W��print(2)

a = 10
b = 1.234234
c = "taguchi"
d = {"fkoji":200, "dot":500}

print "age: %d" % a
print "age: %10d" % a
print "age: %010d" % a
print "price: %f" % b
print "price: %.2f" % b
print "name: %s" % c

print "sales: %(fkoji)d" % d
print "%d and %f" % (a, b)


print "C:\My Document\node\track\test.txt"
print r"C:\My Document\node\track\test.txt"