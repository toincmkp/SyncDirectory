# from �` import �`

from datetime import date

print date.today()
