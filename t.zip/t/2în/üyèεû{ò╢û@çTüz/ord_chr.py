x = 65

print ord("A")
print chr(x)

