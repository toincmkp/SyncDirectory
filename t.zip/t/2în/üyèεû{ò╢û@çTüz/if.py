# if

score = 70

if 60 < score:
	print "ok!"

if 60 < score < 80:
	print "OK!"


score = 45

if score > 60:
	print "ok!"

elif score > 40:
	print "soso..."

else:
	print "ng!"


print "OK!" if score > 60 else "NG!"


a = 15
b = 20
c = 30

if a+b > c and b+c > a and a+c > b:
	print "triangler"

else:
	print "not traiangler"

