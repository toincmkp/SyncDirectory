a = {}
b = {}
a["aaa"] = b

print a
b["ccc"] = "d"
print a["aaa"]["ccc"]