# coding: Shift_Jis
# ���X�g

list = [253, 100, "abc", 400]

print len(list)
print list[2]
list[1] = 101
print list[1]
print 101 in list
print 100 in list

print range(10)
print range(3, 10)
print range(3, 10, 2)


node = [[0], [1, 2]]

node.append([1])
node[2].append(3)

print node

node2 = []

node2.append([1, 3])
node2.append([5, -3])
print node2

