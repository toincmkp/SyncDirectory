def aiueo():
	return 2, 3

a = 0
b = 0

a, b = aiueo()

print a
print b
