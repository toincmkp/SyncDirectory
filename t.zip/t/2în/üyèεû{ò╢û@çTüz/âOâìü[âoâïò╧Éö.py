# グローバル変数

num = 10
list = [12, 35]

def calc():
    global num
    num = 100

    return num ** 2

def calc2():
    global list
    list[0] = 15

print calc()
print num

calc2()
print list
