/* ------------------------------------
	boxer.js
	Mignon Style
	http://mignonstyle.com/
------------------------------------ */
jQuery(function($){
	$('.boxer').boxer();
});