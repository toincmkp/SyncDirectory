# coding: Shift_JIS

# ------------------------------------------------
# �����idict�j

sales = {"ringo":200, "banana":300, "suika":500}
print sales

print sales["ringo"]
sales["banana"] = 800
print sales

print "ringo" in sales

print sales.keys()
print sales.values()
print sales.items()

# ------------------------------------------------
# �����idict�j
#   �������Ɏ������\
print "------------------------------------------"

a = {}
b = {}
a["aaa"] = b

print a
b["ccc"] = "d"
print a["aaa"]["ccc"]
