# coding: Shift_JIS

import base64

s = "CTF\n"

encoding_data = base64.b64encode(s)
print encoding_data

decoding_data = base64.b64decode(encoding_data)
print decoding_data

