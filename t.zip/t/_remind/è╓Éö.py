# coding: Shift_JIS

# ------------------------------------------------
# �֐�
#   �߂�l�̓��X�g�⎫���ł����Ȃ�

def hello1():
	print "hello"

def hello2(name):
	print "hello %s!" % name

def hello3(name, num):
	print "hello %s!" % name * num

def hello4(name, num = 3):
	print "hello %s! " % name * num

def hello5(name, num = 2):
	return "hello %s! " % name * num

hello1()
hello2("tom")
hello3("tom", 3)
hello4("steve")
hello4(num = 2, name = "tom")

s = hello5("Bob")
print s

# ------------------------------------------------
# �֐�
#   �߂�l�ɕ����̒l���w��\
print "------------------------------------------"

def ret2val():
    return 2, 3

a = 0
b = 0

a, b = ret2val()

print a, b
